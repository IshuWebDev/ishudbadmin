Welcome to the IshuDbAdmin. The OpenSource Project 2022.

This is a release of IshuDbAdmin, an Database Management Web application.

This is is official file for instruction to use and utilize the project.

The latest release of application is Version 1.0.1

This project distribution include source code developed by Ishu Gupta.

This is Open Source project. One can modify the project as per their modification requirements.

For Download and Install the project please refer the Github link to download package.
     https://www.github.com/ishuweb/ishudbadmin


Instructions for Deploy Application on Localhost OR LiveServer. Please Consider the Following Steps:-

Step : 1 - Download the package zip file Ishudbadmin_package from github https://www.github.com/ishuweb/ishudbadmin

Step : 2 - Move and Extract the the Ishudbadmin package folder to your Localhost OR LiveServer root directory

Step : 3 - Type Ishudbadmin in browser ex:- '127.0.0.1/ishudbadmin' OR 'domain.com/ishudbadmin'

Enjoy Your Application!

You can contribute any modification on Github are most welcome!!

Ishu Gupta
https://www.github.com/ishuweb